//  file:  vector.cpp

#include "vector.hh"


void vector::sett(void)
{
  if (x_coor != 0)
    theta=atan(y_coor/x_coor);
  else
    {
      if (y_coor > 0)
	theta=pi/2;
      else
	theta=-pi/2;
    }
  if ( x_coor>0 )
    {
      if (y_coor >= 0)
	return;
      if (y_coor<0)
	theta+=2*pi;
      return;
    }
  if (x_coor<0)
    {
      theta+=pi;
      return;
    }
}


bool vector3::operator==(vector3 b) 
{
  return ((x_coor==b.x_coor) && (y_coor==b.y_coor)
	  && (z_coor==b.z_coor));
}


void vector3::setrt(void) 
{
  r=hypot(hypot(x_coor,y_coor),z_coor);
  if (r>0) 
    sett();
  else 
    theta=0;
}


void vector3::setrtp(void)
{
  setrt();
  if (r>0)
    phi = acos(z_coor/r);
  else
    phi=0;
}


void vector3::setxyz(void)
{
  x_coor = r*sin(phi)*cos(theta);
  y_coor = r*sin(phi)*sin(theta);
  z_coor = r*cos(phi);
}


#ifdef USEWITHQT
vector3 operator*(QTime time, vector3 a) 
{
  vector3 b;
  b.r = a.r*time.elapsed()/1000; 
  b.theta=a.theta;
  b.phi=a.phi;
  b.setxyz();
  return b;
}
#endif

vector3 operator+(vector3 a,vector3 b)
{
  vector3 c((a.x_coor+b.x_coor),(a.y_coor+b.y_coor),(a.z_coor+b.z_coor));
  //cout << "inside summation\t" << c << endl;
  return c;
}


vector3 operator/(vector3 a,double b) 
{
  vector3 c;
  c.r = a.r/b;
  c.x_coor=a.x_coor/b;
  c.y_coor=a.y_coor/b;
  c.z_coor=a.z_coor/b;
  return c; 
}


void vector3::setrectangular(double X,double Y,double Z)
{
  x_coor=X;
  y_coor=Y; 
  z_coor=Z; 
  setrtp();
}


void vector3::setpolar(double R, double THETA, double PHI)
{
  r=R;
  theta=THETA;
  phi=PHI;
  setxyz();
}


ostream &operator<<(ostream& cout,vector3 a)
{
  if (a.type == RECTANGULAR)
    cout << "[ " << a.x() << ","
	 << a.y() << ","
	 << a.z() << "]";
  else
        cout << "[ " << a.mag() << "<"
	 << a.xydir() << "<"
	 << a.zdir() << "]";
  return cout;
}


ostream &operator<<(ostream& cout,vector b)
{
  if (b.type == RECTANGULAR)
    cout << "[ " << b.x() << ","
	 << b.y() << "]";
  else
    cout << "[ " << b.mag() << "<"
	 << b.dir() << "]";
  return cout;
}


vector3 cross(vector3 a,vector3 b)
{
  vector3 output(a.y()*b.z()-a.z()*b.y(),
		 a.z()*b.x()-a.x()*b.z(),
		 a.x()*b.y()-a.y()*b.x());
  //cout << "cross product: " << a << "x" << b << " ?= " << output << endl;
  return output;
}

vector3 cross(vector a,vector3 b)
{
  vector3 A(a.x(),a.y(),0);
  return cross(A,b);
}

vector3 cross(vector3 a,vector b)
{
  vector3 B(b.x(),b.y(),0);
  return cross(a,B);
}

vector3 cross(vector a,vector b)
{
  vector3 A(a.x(),a.y(),0);
  vector3 B(b.x(),b.y(),0);
  return cross(A,B);
}


void vector3::cropforcolor(void)
{
  if (x_coor < 0)
    x_coor=0;
  if (y_coor < 0)
    y_coor=0;
  if (z_coor < 0)
    z_coor=0;

  if (x_coor > 255)
    x_coor=255;
  if (y_coor > 255)
    y_coor=255;
  if (z_coor > 255)
    z_coor=255;
}


vector3 operator*(double a, vector3 v)
{
  vector3 b;
  b=v;
  b.r=(a*(v.r));
  b.setxyz();
  return b;
}


void vector::reflect(vector norm)
{
  *this=(*this+(-2*dot(*this,norm)*norm));
}


void vector3::reflect(vector3 norm)
{
  *this=(*this+(-2*dot(*this,norm)*norm));
}
