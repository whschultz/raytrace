//  file:  vector.hh

/********************************************************

This file includes the definition of two classes:

vector   --  a vector in 2D
vector3  --  a vector in 3D

These vectors are nothing like the STL vectors.  These
are true mathematical vectors.  They automatically keep
track of both polar and rectangular coordinates.  As
such, if both are not needed, this may be a less than
efficient implementation of a vector for your needs.


********************************************************/

//If this is going to be used with gpackage, uncomment
//the following line to enable vertex-vector conversions

#define USEWITHGPACKAGE
#define USEWITHQT

#ifndef VECTOR_WHS
#define VECTOR_WHS

#define pi 3.1415926535897946264338

#include <math.h>
#include <iostream.h>
#ifdef USEWITHQT
#include <qdatetime.h>
#include <qpoint.h>
#endif

#ifdef USEWITHGPACKAGE
#include "gpackage.hh"
#endif


typedef enum {RECTANGULAR,POLAR,SPHERICAL} primarytype;

class vector  // vector in R2
{
public:
  vector(double a,double b) {x_coor=a;y_coor=b;setrt();type=RECTANGULAR;}
  vector(void) { type=RECTANGULAR; setrectangular(0,0);}

  virtual ~vector(void) { };

  void settype(primarytype newtype) {type=newtype;}
  primarytype gettype(void) {return type;}

  virtual double norm(void) { return r; }
  virtual double angle(void) {return theta;}
  virtual double x(void) {return x_coor;}
  virtual double y(void) {return y_coor;}
  virtual double mag(void) {return r;}
  virtual double dir(void) {return theta;}

  virtual void makeunit(void) {r=1;setxy();}

  virtual void setpolar(double magnitude,double angle) {r=magnitude;theta=angle;setxy();}
  virtual void setrectangular(double X,double Y) {x_coor=X; y_coor=Y;setrt();}

  friend vector operator*(double a, vector v) {vector b(v.x_coor*a, v.y_coor*a);return b;}
  friend double operator*(vector a, vector b) {return (a.x_coor*b.x_coor+a.y_coor*b.y_coor);}
#ifdef USEWITHQT
  friend vector operator*(QTime time, vector a) 
     {vector b;b.r = a.r*time.elapsed()/1000; b.theta=a.theta;b.setxy();return b;}
  friend vector operator*(vector a, QTime time) {return time*a;}
#endif
  friend vector operator+(vector a,vector b) {vector c(a.x_coor+b.x_coor,a.y_coor+b.y_coor); return c;}
  friend vector operator/(vector a,double b) {vector c; c.r = a.r/b; c.x_coor=a.x_coor/b; c.y_coor=a.y_coor/b; return c; }
  friend vector operator-(vector a,vector b) {return (a+(-1)*b);}

  friend ostream &operator<<(ostream&,vector);

#ifdef USEWITHGPACKAGE
  friend vertex operator+(vertex a,vector b) {vertex c(a.x()+b.x_coor,a.y()+b.y_coor); return c;}
  friend vertex operator+(vector b,vertex a) {return a+b;}

  virtual bool operator=(QPoint b) {setrectangular(b.x(),b.y());return 1;}
#endif
  virtual bool operator==(vector b) {return ((x_coor==b.x_coor) && (y_coor==b.y_coor));}
  virtual bool operator=(vector b) {setrectangular(b.x_coor,b.y_coor); return 1;}

  virtual void reflect(vector norm) {theta = 2*norm.theta-theta; setxy(); }

protected:
  virtual void setrt(void) {r=hypot(x_coor,y_coor);if (r>0) sett(); else theta=0;}
  virtual void sett(void);
  virtual void setxy(void) {x_coor=r*cos(theta);y_coor=r*sin(theta);}

  double x_coor,y_coor;
  double r,theta;   //  if r is a velocity, it is in units/second

  primarytype type;
};



class vector3 : public vector
{
public:
  //  constructors/destructors
  vector3(void) { type=RECTANGULAR; setrectangular(0,0,0);}
  vector3(double X,double Y,double Z) {setrectangular(X,Y,Z);type=RECTANGULAR;}
  
  //  simple functions
  double z(void)     {return z_coor;}
  double zdir(void)  {return phi;}
  double xydir(void) {return theta;}
  virtual void reflect(vector3 norm);
  virtual void makeunit(void) {setrtp();r=1;setxyz();}

  //  set the vector in either polar or rectangular.  Automatically keeps up with both
  virtual void setrectangular(double,double,double);
  virtual void setpolar(double,double,double);

  //  boolean operators
  bool operator==(vector3 b);
  bool operator==(vector b) {return ((vector::operator==(b)) && (z_coor==0));}

  //  arithmetic operators
  virtual bool operator=(vector3 b) {setrectangular(b.x_coor,b.y_coor,b.z_coor); return 1;}
  virtual bool operator=(vector  b) {setrectangular(b.x(),b.y(),0); return 1;}
  friend vector3 operator*(double a, vector3 v) {vector3 b;b=v;b.r=a*v.r;b.setxyz();return b;}
  friend double operator*(vector3 a, vector3 b) {return (a.x_coor*b.x_coor+a.y_coor*b.y_coor+a.z_coor*b.z_coor);}
#ifdef USEWITHQT
  bool operator=(QPoint  b) {z_coor=0;phi=pi/2;vector::operator=(b);return 1;}
  friend vector3 operator*(QTime, vector3);
  friend vector3 operator*(vector3 a, QTime time) {return time*a;}
#endif
  friend vector3 operator+(vector3 a,vector3 b);
  friend vector3 operator/(vector3 a,double b) {return (1/b)*a;}
  friend vector3 operator-(vector3 a,vector3 b) {return (a+(-1)*b);}

  //  iostream operator
  friend ostream &operator<<(ostream&,vector3);

  void cropforcolor(void);

private:
  //  functions used to keep up with coordinate systems
  virtual void setrt(void);
  virtual void setrtp(void);
  virtual void setxyz(void);

  //  the only values added over a 2D vector
  double   phi; // angle with z axis
  double   z_coor;
};


// this is the only way to call a cross product
vector3 cross(vector,vector);
vector3 cross(vector,vector3);
vector3 cross(vector3,vector);
vector3 cross(vector3,vector3);

#define dot(x,y) (x*y)

// I don't know why, but I had to use a macro for it to compile

//double dot(vector3 a,vector3 b) {return (a*b);}
//double dot(vector a,vector b) {return (a*b);}



#endif
