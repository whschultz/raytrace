//  file:  raytrace.cpp
//     screen res:  720x486
#include "raytrace.hh"
#include <iostream.h>
#include <qdatastream.h>


/*****************************************************/
//  functions for raytraceobject

raytraceobject::raytraceobject(void)
{
  ambient=0;
  diffuse=0;
  specular=0;
  phong=1;
  center.setrectangular(0,0,0);
  color.setrectangular(255,255,255);
  background.setrectangular(150,100,255);
  radius=5;
}


void raytraceobject::setambient(double a)
{
  ambient=a;
  if (ambient+diffuse+specular > 1)
    {
      diffuse=diffuse/(diffuse+specular);
      specular=1-(ambient+diffuse);
    }
  return;
}


void raytraceobject::setdiffuse(double d)
{
  diffuse=d;
  if (ambient+diffuse+specular > 1)
    {
      ambient=ambient/(ambient+specular);
      specular=1-(ambient+diffuse);
    }
  return;
}



void raytraceobject::setspecular(double s)
{
  specular=s;
  if (ambient+diffuse+specular > 1)
    {
      ambient=ambient/(ambient+diffuse);
      diffuse=1-(ambient+specular);
    }
  return;
}


vector3 raytraceobject::intersect(vector3 start, vector3 direction, double *t)
{
  vector3 radicalv;
  double spare,intermediate;
  vector3 dp=center-start;
  radicalv=dp-(direction*dp)*direction;
  spare=(radius*radius)-(radicalv*radicalv);
  if (spare < 0)
    {
      *t=(-1);
      return (start-direction);
    }
  intermediate=direction*dp;
  *t=((intermediate)-(pow(spare,.5)));
  return start+(*t)*direction;
}


vector3 raytraceobject::intersectcolor(vector3 start,vector3 direction,
				       double *t, lightsource light)
{
  vector3 outputcolor=color;
  vector3 norm;
  vector3 intersection;
  vector3 lightfactor;
  vector3 output=background;
  intersection=intersect(start,direction,t);
  if (*t<0)
    return output;

  norm=intersection-center;
  norm.makeunit();
  outputcolor=light.diffuse(intersection,norm,direction,diffuse,ambient,phong,color);
  
  outputcolor.cropforcolor();
  
  return outputcolor;
}


void raytraceobject::setcenter(vector3 newcenter)
{
  center=newcenter;
}


void raytraceobject::setradius(double newradius)
{
  radius=newradius;
}


void raytraceobject::setcolor(int r,int g,int b)
{
  color.setrectangular(r,g,b);
}


vector3 raytraceobject::reflect(vector3 start,vector3 direction,double t)
{
  vector3 output=direction;
  vector3 pointnorm=getnorm(start+(t*direction));
  output.reflect(pointnorm);
  return output;
}


vector3 raytraceobject::getnorm(vector3 atpoint)
{
  vector3 norm=(atpoint-center);
  norm.makeunit();
  return norm;
}
