//  file:  raytrace.hh

#ifndef BREAKOUT
#define BREAKOUT

#include "gpackage.hh"
#include "vector.hh"
#include "matrix.hh"
#include <qdatetime.h>
#include <qcursor.h>
#include <qcolor.h>

#define MAXOBJECTS 128
#define MAXLIGHTS  16


typedef enum {PLAIN,CHECKERED} pattern;

class lightsource
{
public:
  lightsource(void);
  ~lightsource(void);

  vector3 specular(vector3,vector3);
  vector3 diffuse(vector3,vector3,double,double);

  void setcolor(double,double,double); // 0.0 to 1.0
  void setcolor(int,int,int);          // 0 to 255
  void setposition(double,double,double);

  vector3 getpos(void) {return position;}
private:
  vector3 position;
  vector3 color; // range from 0 to 1
};


class raytraceobject
{
public:
  raytraceobject(void);
  virtual ~raytraceobject(void) { };
  virtual vector3 intersect(vector3,vector3,double *); // returns intersect point
  virtual vector3 intersectcolor(vector3,vector3,double *,lightsource); // returns color
  virtual vector3 reflect(vector3,vector3,double);
  virtual void setcenter(vector3);
  virtual void setcenter(double x,double y,double z) {center.setrectangular(x,y,z);}
  virtual void setradius(double);
  virtual void setcolor(int,int,int);
  virtual void setbackground(vector3 b) {background=b;}
  virtual void setbackground(int r,int g,int b) {background.setrectangular(r,g,b);}
  virtual void setambient(double a)  {ambient=a;}
  virtual void setdiffuse(double d)  {diffuse=d;}
  virtual void setspecular(double s) {specular=s;}
protected:
  vector3  center;
  double   radius;
  vector3  color;
  vector3  background;
  double   ambient;
  double   diffuse;
  double   specular;
};


class sphere : public raytraceobject
{
public:
  sphere(void);
  ~sphere(void);
};


class plane : public raytraceobject
{
public:
  plane(void);
  ~plane(void);

  virtual vector3 intersect(vector3,vector3,double *);
  virtual vector3 intersectcolor(vector3,vector3,double *,lightsource);
  virtual vector3 reflect(vector3,vector3,double *);
  virtual void setpoint(double x,double y,double z) {point.setrectangular(x,y,z);}
  virtual void setnormal(double x,double y,double z) {normal.setrectangular(x,y,z);normal.makeunit();}
private:
  vector3 point;
  vector3 normal;
  pattern p;
};


class raytraceobjects
{
public:
  raytraceobjects(void);
  ~raytraceobjects(void);
  
  bool addobject(raytraceobject *);
  bool addlight(lightsource *);
  QColor followray(vector3,vector3);
  vector3 intersect(vector3,vector3,double *);
  void setbackground(double,double,double);

private:
  vector3 background;
  raytraceobject **objects;
  lightsource    **lights;
  int numobjects,numlights;
  sphere A;
  lightsource B;
};


class camera : public QWidget
{
  Q_OBJECT
public:
  camera(GP_Object *);
  ~camera(void) {}

  void tracescreen(void);
  void remapobjs(void);
  void setobjects(raytraceobjects *newobjs) {objects=newobjs;}
  
  void setlookat(double,double,double);
  void settop(double,double,double);
  void setpos(double,double,double);

public slots:
  void drawscreen(void) {tracescreen();}

private:
  vector3  lookat;
  vector3  head;
  vector3  position;
  //double   vert,horiz;
  raytraceobjects *objects;
  GP_Object *gpobject;
  matrix transform;
};


#endif
