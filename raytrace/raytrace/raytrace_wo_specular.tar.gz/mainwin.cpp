/****************************************************************************
** mainwin.cpp
****************************************************************************/


#include <qpushbutton.h>
#include <qslider.h>
#include <qlayout.h>
#include <qframe.h>
#include <qmenubar.h>
#include <qpopupmenu.h>
#include <qapplication.h>
#include <qkeycode.h>
#include <qstring.h>
#include "mainwin.hh"
#include "gpackage.hh"
#include "namewin.hh"

#include <iostream.h>



//Constructor for the main window.  It is here that all the work is carried out
//necessary to create the window and all its parts (buttons, menus, etc...)

MainWindow::MainWindow( QWidget* parent, const char* name )
  : QWidget( parent, name )
{
  QFrame* f = new QFrame( this, "frame" );
  gpobject = new GP_Object( f, "gpobject");

  raycamera = new camera(gpobject);
  raycamera->setobjects(&objects);

  raycamera->setpos(0,5,15);
  raycamera->setlookat(0,-5,-15);
  raycamera->settop(0,1,0);


  sphere *sparesphere=new sphere;
  plane  *spareplane=new plane;
  lightsource *sparelight=new lightsource;

  spareplane->setpoint(0,-3,0);
  spareplane->setnormal(0,1,-.2);
  spareplane->setambient(0);
  spareplane->setdiffuse(1);
  spareplane->setcolor(255,255,255);

  objects.addobject(spareplane);

  sparesphere->setcenter(-3,0,0);
  sparesphere->setradius(3);
  sparesphere->setambient(.1);
  sparesphere->setdiffuse(.9);
  sparesphere->setcolor(255,255,255);

  objects.addobject(sparesphere);

  sparesphere=new sphere;

  sparesphere->setcenter(3,0,0);
  sparesphere->setradius(3);
  sparesphere->setambient(.1);
  sparesphere->setdiffuse(.9);
  sparesphere->setcolor(255,255,255);

  objects.addobject(sparesphere);

  sparesphere=new sphere;

  sparesphere->setcenter(0,0,0);
  sparesphere->setradius(2);
  sparesphere->setambient(.1);
  sparesphere->setdiffuse(.9);
  sparesphere->setcolor(255,255,255);

  objects.addobject(sparesphere);

  sparelight->setcolor(255,0,0);
  sparelight->setposition(-6,6,0);

  objects.addlight(sparelight);

  sparelight=new lightsource;
  sparelight->setcolor(0,0,255);
  sparelight->setposition(6,6,0);

  objects.addlight(sparelight);

  sparelight=new lightsource;
  sparelight->setcolor(0,255,0);
  sparelight->setposition(0,6,0);

  objects.addlight(sparelight);

  //mouse.setShape(PointingHandCursor);
  //setCursor(mouse);
  
  

  // Create top-level layout manager  (vertical)
  QVBoxLayout* vlayout = new QVBoxLayout( this, 20, 20, "vlayout");
  
  // Create a menu item "File"
  QPopupMenu *file = new QPopupMenu();
  file->insertItem( "Exit",  qApp, SLOT(quit()), CTRL+Key_Q );
  
  /*
  //Create menu item "Object Type"
  QPopupMenu *objtyp = new QPopupMenu();
  objtyp->insertItem( "Line", gpobject, SLOT(ObjectModeLINE()));
  objtyp->insertItem( "Empty Polygon" , gpobject, SLOT(ObjectModeOPEN()));
  objtyp->insertItem( "Opaque Polygon" , gpobject, SLOT(ObjectModeCLOSED()));

  //Create menu item "Line Style"
  QPopupMenu *lintype = new QPopupMenu();
  lintype->insertItem( "Continuous", gpobject, SLOT(LineModeCONT()));
  lintype->insertItem( "Dashed", gpobject, SLOT(LineModeDASH()));
  lintype->insertItem( "Dotted", gpobject, SLOT(LineModeDOT()));

  //Create menu item "Colors"
  QPopupMenu *color = new QPopupMenu();
  color->insertItem( "Line Color" , gpobject, SLOT(setLineColor()));
  color->insertItem( "Polygon Color", gpobject, SLOT(setPolyColor()));

  //Create menu item "Edit Style"
  QPopupMenu *edit = new QPopupMenu();
  edit->insertItem( "Draw Mode" , gpobject, SLOT(EditModeDRAW()));
  edit->insertItem( "Edit Mode" , gpobject, SLOT(EditModeMODIFY()));
  edit->insertItem( "Delete Mode", gpobject, SLOT(EditModeDELETE())); */

  //Create menu item "Play Game"
  //QPopupMenu *gameMenu = new QPopupMenu();
  //gameMenu->insertItem( "Start Game" , game, SLOT(startgame()));
  
  //Create menu item "Ray Trace"
  QPopupMenu *raytrace = new QPopupMenu();
  raytrace->insertItem("Draw Screen", raycamera, SLOT(drawscreen()));

  // Create a menu bar
  QMenuBar *m = new QMenuBar( this );
  m->setSeparator( QMenuBar::InWindowsStyle );
  m->insertItem("&File", file );
  m->insertItem("&Ray Trace",raytrace);
  //m->insertItem("O&bject Type", objtyp);
  //m->insertItem("&Line Style",lintype);
  //m->insertItem("Colo&rs" , color);
  //m->insertItem("&Edit Style" , edit);
  //m->insertItem("&Game" , gameMenu);
  vlayout->setMenuBar( m );
  
  // Create a nice frame to put around the gpobject widget
 
  f->setFrameStyle( QFrame::Sunken | QFrame::Panel );
  f->setLineWidth( 10 );
  vlayout->addWidget( f, 1 );
  
  // Create a layout manager for the gpobject widget
  QHBoxLayout* flayout = new QHBoxLayout( f, 2, 2, "flayout");
  
  // Create an gpobject widget
  if ( !gpobject->isValid() )
    fatal("Failed to create Gpobject rendering context on this display");
  gpobject->setMinimumSize( 720,486 );
  gpobject->setMaximumSize( 720, 486 );
  gpobject->setGeometry( 0, 0, 720, 486 );
  //must enable mouse tracking to grab mouse location
  gpobject->setMouseTracking( TRUE );
 
  gpobject->makeCurrent();
  flayout->addWidget( gpobject, 1 );
  flayout->activate();
  
  
  //Label for messages to user
  mlabel = new QLabel(this);
  CHECK_PTR( mlabel );
  mlabel->setFrameStyle( QFrame::Panel | QFrame::Raised );
  mlabel->setAlignment( AlignBottom | AlignHCenter);
  mlabel->setLineWidth( 1 );
  mlabel->setFixedHeight( 25 );
  mlabel->setText( "" );
  mlabel->setFont(QFont("Helvetica", 10));
  vlayout->addWidget( mlabel, 1 ); 
  //This connection must remain here to wait for ulabel's creation
  connect(gpobject, SIGNAL(glmessage(const QString&)), 
	  mlabel, SLOT(setText(const QString&)));
  connect(this, SIGNAL(message(const QString&)), 
	  mlabel, SLOT(setText(const QString&)));
  
  // Start the geometry management
  //game->setBreakout(0);
  gpobject->GP_UpdateScreen();
  vlayout->activate();
}



//deallocate resources

MainWindow::~MainWindow()
{
  delete gpobject;
  delete mlabel;
}



//emits a signal to the gpobject canvas to clear it to black 
    
void MainWindow::clearCanvas()
{
  emit clearScr();
}   

/* void MainWindow::setLineMode(LineMode input)
{
  gpobject->newLineMode(input);
  } */


//gets the user's name and displays it

void MainWindow::getName()
{
  QString before, after;

  before.sprintf("Hello ");
  after.sprintf("! To begin, select \"Start Game\" from the Game menu.");


  //create the name dialog window and set its size and location
  NameWindow *w;
  w = new NameWindow(this, "namewin");
  w->setGeometry(500, 300, 100, 100);

  //the actions in if(w->exec()) will be carried out if the user selects ok
  //else it wil carry out whats in the else portion of the statement
  if(w->exec())
    {
      QString name;
      
      name = w->returnName();

      before += name;
      before += after;
      emit message(before);
    }
  else
    emit message("Hello!  To begin, select \"Start Game\" from the Game menu.");

    delete w;
}
