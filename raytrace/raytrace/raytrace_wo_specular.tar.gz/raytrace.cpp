//  file:  raytrace.cpp
//     screen res:  720x486
#include "raytrace.hh"
#include <iostream.h>
#include <qstring.h>
#include <qdatastream.h>


/*****************************************************/
//  functions for raytraceobject

raytraceobject::raytraceobject(void)
{
  ambient=0;
  diffuse=1.0;
  center.setrectangular(0,0,0);
  color.setrectangular(255,255,255);
  background.setrectangular(150,100,255);
  radius=5;
}


vector3 raytraceobject::intersect(vector3 start, vector3 direction, double *t)
{
  vector3 radicalv;
  double spare,intermediate;
  vector3 dp=center-start;
  radicalv=dp-(direction*dp)*direction;
  spare=radius*radius-radicalv*radicalv;
  if (spare < 0)
    {
      *t=-1;
      return start-direction;
    }
  intermediate=direction*dp;
  *t=intermediate-pow(spare,.5);
  return start+(*t)*direction;
}


vector3 raytraceobject::intersectcolor(vector3 start,vector3 direction,
				       double *t, lightsource light)
{
  vector3 outputcolor=color;
  vector3 norm;
  vector3 intersection;
  vector3 lightfactor;
  vector3 output=background;
  intersection=intersect(start,direction,t);
  if (*t<0)
    return output;

  norm=intersection-center;
  norm.makeunit();
  lightfactor=light.diffuse(intersection,norm,diffuse,ambient);
  outputcolor.setrectangular(lightfactor.x()*outputcolor.x(),
			     lightfactor.y()*outputcolor.y(),
			     lightfactor.z()*outputcolor.z());
  outputcolor=ambient*color+outputcolor;
  
  outputcolor.cropforcolor();

  //output.setRgb(outputcolor.x(),outputcolor.y(),outputcolor.z());
  
  //  add more to this later
  return outputcolor;
}


void raytraceobject::setcenter(vector3 newcenter)
{
  center=newcenter;
}


void raytraceobject::setradius(double newradius)
{
  radius=newradius;
}


void raytraceobject::setcolor(int r,int g,int b)
{
  color.setrectangular(r,g,b);
}


vector3 raytraceobject::reflect(vector3 start,vector3 direction,double t)
{
  vector3 location=start+t*direction;
  vector3 norm=location-center;
  vector3 output=direction;
  output.reflect(norm);
  return output;
}


/*****************************************************/
//  functions for camera

camera::camera(GP_Object *newgp)
{
  lookat.setrectangular(0,-1,-1);
  lookat.makeunit();
  head.setrectangular(0,1,0);
  position.setrectangular(0,10,10);
  gpobject=newgp;
}


void camera::setlookat(double x, double y, double z)
{
  lookat.setrectangular(x,y,z);
  lookat.makeunit();
}


void camera::settop(double x, double y, double z)
{
  head.setrectangular(x,y,z);
}


void camera::setpos(double x,double y,double z)
{
  position.setrectangular(x,y,z);
}



void camera::remapobjs(void)
{

}


void camera::tracescreen(void)
{
  vector3  direction;
  vector3  topleft,topright,bottomleft,bottomright,spare,currentxy;
  vector3  Xdir,Ydir,right;
  int X=0,Y=0;
  QColor current;

  right=cross(lookat,head);
  head=cross(right,lookat);  // make head normal to lookat
  right.makeunit();
  head.makeunit();
  
  topright=(lookat+right+486*head/720);
  topleft=(lookat-right+486*head/720);
  bottomleft=(lookat-right-486*head/720);
  bottomright=(lookat+right-486*head/720);

  Xdir=topright-topleft;
  Xdir= Xdir/720;
  Ydir=(bottomleft-topleft)/486.0;

  spare=topleft;

  for(X=0;X<=720;X++)
    {
      currentxy=spare;
      for(Y=0;Y<=486;Y++)
	{
	  direction=(lookat+currentxy);
	  direction.makeunit();
	  current=objects->followray(position,direction);
	  gpobject->GP_DrawPixel(X,486-Y,current);
	  currentxy=currentxy+Ydir;
	}
      spare=spare+Xdir;
      //if (X%40 == 0)
      gpobject->GP_RefreshScreen();
    }
}


/*****************************************************/
//  functions for raytraceobjects

raytraceobjects::raytraceobjects()
{
  //  change this
  objects=new (raytraceobject *)[MAXOBJECTS];
  lights=new (lightsource *)[MAXLIGHTS];
  for(int x=0;x<MAXOBJECTS;x++)
    objects[x]=NULL;
  for(int x=0;x<MAXLIGHTS;x++)
    lights[x]=NULL;
  numobjects=0;
  numlights=0;
  
  setbackground(150,100,255);
  
  vector3 newcenter(0,0,0);
  
  A.setcenter(newcenter);
  A.setradius(3);
  A.setcolor(255,0,255);
  A.setbackground(150,100,255);
  A.setambient(.1);
  A.setdiffuse(1.0);
  A.setspecular(.5);

  B.setposition(0,10,0);
  B.setcolor(255,0,0);
}


void raytraceobjects::setbackground(double r,double g,double b)
{
  background.setrectangular(r,g,b); 
  background.cropforcolor();
  for(int x=0;x<numobjects;x++)
    objects[x]->setbackground(background);
}


vector3 raytraceobjects::intersect(vector3 start,vector3 direction,double *location)
{
  double t=1,smallest=-2;
  int numofsmallest=-1;
  *location=-1;
  //start=(start+(.01*direction));
  for(int x=0;x<numobjects;x++)
    {
      objects[x]->intersect(start,direction,&t);
      if (t<=.00001)
	continue;
      else
	{
	  if (numofsmallest==-1)
	    {
	      smallest=t;
	      numofsmallest=x;
	      continue;
	    }
	  if (t<smallest)
	    {
	      smallest=t;
	      numofsmallest=x;
	    }
	}
    }
  if (numofsmallest != -1)
    *location=smallest;
  return (start+(smallest)*direction);
}


QColor raytraceobjects::followray(vector3 start,vector3 direction)
{
  double t=1,smallest=-2;
  //double checkforshadows;
  int numofsmallest=-1;
  QColor  outputcolor;
  vector3 outputcolorv(0,0,0);
  vector3 spare;

  for(int x=0;x<numobjects;x++)
    {
      objects[x]->intersect(start,direction,&t);
      if (t<=0)
	continue;
      else
	{
	  if (numofsmallest==-1)
	    {
	      smallest=t;
	      numofsmallest=x;
	      continue;
	    }
	  if (t<smallest)
	    {
	      smallest=t;
	      numofsmallest=x;
	    }
	}
    }
  vector3 intersectionpoint,newdirection;
  double shadowpoint,distance;
  if (numofsmallest != -1)
    {
      intersectionpoint=start+(smallest)*direction;
      
      for(int y=0;y<numlights;y++)
	{
	  newdirection=((lights[y]->getpos())-intersectionpoint);
	  distance=newdirection.norm();
	  newdirection.makeunit();
	  intersect(intersectionpoint,newdirection,&shadowpoint);
	  //cout << shadowpoint << "  " << distance << endl;
	  if ((shadowpoint < 0) || (shadowpoint > distance))
	    outputcolorv=(outputcolorv+(objects[numofsmallest]->intersectcolor(start,direction,&t,*(lights[y]))));
	}
    }
  else
    outputcolorv=background;
  
  //outputcolorv=A.intersectcolor(start,direction,&t,B);
  
  outputcolorv.cropforcolor();
  outputcolor.setRgb(outputcolorv.x(),
		     outputcolorv.y(),
		     outputcolorv.z());
  
  return outputcolor;
}


raytraceobjects::~raytraceobjects(void)
{
  for(int x=0;x<MAXOBJECTS;x++)
    {
      if (objects[x] != NULL)
	delete objects[x];
    }
  delete [] objects;
  for(int x=0;x<MAXLIGHTS;x++)
    {
      if (lights[x] != NULL)
	delete lights[x];
    }
  delete [] lights;
}


bool raytraceobjects::addobject(raytraceobject *newobject)
{
  if (numobjects >= MAXOBJECTS)
    return 0;
  newobject->setbackground(background);
  objects[numobjects]=newobject;
  numobjects++;
  return 1;
}


bool raytraceobjects::addlight(lightsource *newlight)
{
  if (numlights >= MAXLIGHTS)
    return 0;
  
  lights[numlights]=newlight;
  numlights++;
  return 1;
}


/*****************************************************/
//  functions for sphere

sphere::sphere(void)
{
  vector3 newcenter(0,0,0);
  setcenter(newcenter);
  setradius(20);
  setcolor(255,255,255);
}


sphere::~sphere(void)
{

  return;
}


/*****************************************************/
//  functions for lightsource

lightsource::lightsource(void)
{
  position.setrectangular(0,0,0);
  color.setrectangular(1,1,1);
}


lightsource::~lightsource(void)
{

}


void lightsource::setposition(double x,double y,double z)
{
  position.setrectangular(x,y,z);
}


vector3 lightsource::diffuse(vector3 point,vector3 norm,double diffuse,double ambient)
{
  double multiplier;
  if (norm.mag() != 1)
    norm.makeunit();
  vector3 direction=(position-point);
  direction.makeunit();
  multiplier=norm*direction+diffuse*ambient;
  return (multiplier*color);
}


vector3 lightsource::specular(vector3 a,vector3 b)
{
  return color;
}


void lightsource::setcolor(double r,double g,double b)
{
  color.setrectangular(r,g,b);
}


void lightsource::setcolor(int r,int g,int b)
{
  color.setrectangular(double(r)/255.0,
		       double(g)/255.0,
		       double(b)/255.0);
}


/*********************************************************/
//  function calls for plane

plane::plane(void)
{
  normal.setrectangular(0,0,1);
  point.setrectangular(0,0,0);
}


plane::~plane(void)
{

}


vector3 plane::intersect(vector3 start,vector3 direction,double *t)
{
  if (!dot(direction,normal))
    *t=-1;
  else
    *t=(dot(point,normal)-dot(start,normal))/dot(direction,normal);
  return (start+(*t)*direction);
}


vector3 plane::intersectcolor(vector3 start,vector3 direction,double *t,lightsource light)
{
  if (!dot(direction,normal))
    {
      *t=-1;
      return background;
    }
  vector3 outputcolor=color;
  vector3 intersection;
  vector3 lightfactor;

  intersection=intersect(start,direction,t);

  lightfactor=light.diffuse(intersection,normal,diffuse,ambient);
  outputcolor.setrectangular(lightfactor.x()*outputcolor.x(),
			     lightfactor.y()*outputcolor.y(),
			     lightfactor.z()*outputcolor.z());
  outputcolor=ambient*color+outputcolor;
  
  outputcolor.cropforcolor();
  
  return outputcolor;
}


vector3 plane::reflect(vector3 start,vector3 direction,double *t)
{
  vector3 reflected_vector=direction;
  reflected_vector.reflect(normal);
  return intersect(start,direction,t);
}
