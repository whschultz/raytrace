/*
 *  vector.mm
 *  Modeler
 *
 *  Created by William H. Schultz  on Wed Mar 13 2002.
 *  Copyright (c) 2001 __MyCompanyName__. All rights reserved.
 *
 */

//#import "vector.h"
#include "vector.hh"

vector::vector(void)
{
    x_coor = 0;
    y_coor = 0;
    z_coor = 0;
    r = 0;
    theta = 0;
    phi = 0;
    mode = 3;  // both are valid
}


vector::vector(double x,double y,double z)
{
    x_coor = x;
    y_coor = y;
    z_coor = z;
    mode = 1;  // only rectangular is valid
}


vector::vector(const vector &startingPoint)
{
    x_coor = startingPoint.x_coor;
    y_coor = startingPoint.y_coor;
    z_coor = startingPoint.z_coor;
    r = startingPoint.r;
    theta = startingPoint.theta;
    phi = startingPoint.phi;
    mode = startingPoint.mode;
}

void vector::set_equal_to(const vector &startingPoint)
{
    x_coor = startingPoint.x_coor;
    y_coor = startingPoint.y_coor;
    z_coor = startingPoint.z_coor;
    r = startingPoint.r;
    theta = startingPoint.theta;
    phi = startingPoint.phi;
    mode = startingPoint.mode;
}

int  vector::check_equal(const vector &reference)
{
    switch (mode)
      {
        case 1:
        case 3:
            return ((x_coor == reference.x_coor) &&
                    (y_coor == reference.y_coor) &&
                    (z_coor == reference.z_coor));
            break;
        case 2:
            return ((r == reference.r) &&
                    (theta == reference.theta) &&
                    (phi == reference.phi));
            break;
        default:
            return 0;
      }
}


void vector::set_x(double new_x)
{
    x_coor = new_x;
    return;
}


void vector::set_y(double new_y)
{
    y_coor = new_y;
    return;
}


void vector::set_z(double new_z)
{
    z_coor = new_z;
    return;
}


void vector::set_r(double new_r)
{
    r = new_r;
    return;
}


void vector::set_theta(double new_theta)
{
    theta = new_theta;
    return;
}


void vector::set_phi(double new_phi)
{
    phi = new_phi;
    return;
}


double vector::get_x(void)
{
    if (mode == 2)  // then this is not a valid request
        update_rectangular();
    return x_coor;
}


double vector::get_y(void)
{
    if (mode == 2)  // then this is not a valid request
        update_rectangular();
    return y_coor;
}


double vector::get_z(void)
{
    if (mode == 2)  // then this is not a valid request
        update_rectangular();
    return z_coor;
}

double vector::get_r(void)
{
    if (mode == 1)  // then this is not a valid request
        update_spherical();
    return r;
}

double vector::get_theta(void)
{
    if (mode == 1)  // then this is not a valid request
        update_spherical();
    return theta;
}

double vector::get_phi(void)
{
    if (mode == 1)  // then this is not a valid request
        update_spherical();
    return phi;
}

void vector::setrectangular(double new_x,double new_y,double new_z)
{
    x_coor = new_x;
    y_coor = new_y;
    z_coor = new_z;
    mode = 1;  //  rectangular valid
}

void vector::set_spherical(double new_r,double new_theta,double new_phi)
{
    r = new_r;
    theta = new_theta;
    phi = new_phi;
    mode = 2;  //  spherical valid
}


void vector::update_spherical(void)
{
    if (mode >= 2)
        return;  // spherical is already valid

    r=hypot(hypot(x_coor,y_coor),z_coor);
    if (r>0)
      {
        //  set theta
        if (x_coor != 0)
            theta=atan(y_coor/x_coor);
        else
          {
            if (y_coor > 0)
                theta=pi/2;
            if (y_coor < 0)
                theta=-pi/2;
            if (y_coor == 0)
                theta=0;
          }
        if ( x_coor>0 )
          {
            /*if (y_coor >= 0)
                return;*/
            if (y_coor<0)
                theta+=2*pi;
            //break;
          }
        else if (x_coor<0)
          {
            theta+=pi;
            //break;
          }
      }
    else
        theta=0;
    // the breaks should put us here
    
    //  set phi
    
    if (r>0)
        phi = acos(z_coor/r);
    else
        phi=0;

    mode = 3;  //  both are valid now
    
    return;
}

void vector::update_rectangular(void)
{
    if (mode != 2)  // then we're set
        return;
    
    x_coor = r*sin(phi)*cos(theta);
    y_coor = r*sin(phi)*sin(theta);
    z_coor = r*cos(phi);

    mode = 3;  //  because both are valid now

    return;
}


double vector::dot(vector variable)
{
    if (mode == 2)  //  we want rectangular for this method
        update_rectangular();
    if (variable.mode == 2)
        variable.update_rectangular();
    return ((this->x_coor * variable.x_coor) +
            (this->y_coor * variable.y_coor) +
            (this->z_coor * variable.z_coor));
}


vector vector::cross(vector variable)
{
    if (mode == 2)  //  we want rectangular for this method
        update_rectangular();
    if (variable.mode == 2)
        variable.update_rectangular();
    return *(new vector(y_coor*variable.z_coor - z_coor*variable.y_coor,
                       z_coor*variable.x_coor - x_coor*variable.z_coor,
                       x_coor*variable.y_coor - y_coor*variable.x_coor));
}	
    

vector vector::add(vector variable)
{
    if (mode == 2)  //  we want rectangular for this method
        update_rectangular();
    if (variable.mode == 2)
        variable.update_rectangular();
    return *(new vector(x_coor + variable.x_coor,
                       y_coor + variable.y_coor,
                       z_coor + variable.z_coor));
}


vector vector::subtract(vector variable)
{
  vector variablecopy;
  variablecopy.set_equal_to(variable);
  variablecopy.multiply(-1);
  return this->add(variablecopy);
}


double vector::norm(void)
{
    if (mode != 1)
        return r;
    // return hypot(hypot(x_coor,y_coor),z_coor);
    return sqrt(x_coor * x_coor +  // hopefully, this is faster
                y_coor * y_coor +
                z_coor * z_coor);
}


void vector::make_unit(void)
{
    //  r = hypot(hypot(x_coor,y_coor),z_coor);
    //  this.divide(r);
    //  elegant code, but maybe this will be more efficient
    
    if (mode != 2)
      {
        if (mode == 1)
            r = hypot(hypot(x_coor,y_coor),z_coor);
        x_coor /= r;
        y_coor /= r;
        z_coor /= r;
      }
    if (mode != 1)
      {
        r = 1;
      }
}


vector vector::multiply(double variable)
{
  vector v;
  v.set_equal_to(*this);
    if (mode != 2)
      {
        v.x_coor *= variable;
        v.y_coor *= variable;
        v.z_coor *= variable;
      }
    if (mode != 1)
      {
        v.r *= variable;
      }
    return v;
}


vector vector::divide(double variable)
{
  vector v;
  v.set_equal_to(*this);
    if (mode != 2)
      {
        v.x_coor /= variable;
        v.y_coor /= variable;
        v.z_coor /= variable;
      }
    if (mode != 1)
      {
        v.r /= variable;
      }
    return v;
}


void vector::makeunit(void)
{
  set_spherical(1,get_theta(),get_phi());
}


void vector::reflect(vector norm)
{
  vector normcopy;
  normcopy.set_equal_to(norm);
  normcopy.multiply(-2*this->dot(norm));
  this->set_equal_to(this->add(normcopy));

  //*this=(*this+(-2*dot(*this,norm)*norm));
}


vector operator+(vector a,vector b)
{
  return a.add(b);
}


vector operator/(vector a,double b) 
{
  return a.multiply(1/b);
}


vector cross(vector a,vector b)
{
  //  a.update_rectangular();
  //  b.update_rectangular();
  vector3 output(a.get_y()*b.get_z()-a.get_z()*b.get_y(),
                 a.get_z()*b.get_x()-a.get_x()*b.get_z(),
                 a.get_x()*b.get_y()-a.get_y()*b.get_x());
  //cout << "cross product: " << a << "x" << b << " ?= " << output << endl;
  return output;
}



void vector::cropforcolor(void)
{
  update_rectangular();
  if (x_coor < 0)
    x_coor=0;
  if (y_coor < 0)
    y_coor=0;
  if (z_coor < 0)
    z_coor=0;

  if (x_coor > 255)
    x_coor=255;
  if (y_coor > 255)
    y_coor=255;
  if (z_coor > 255)
    z_coor=255;
  mode=1;
}
