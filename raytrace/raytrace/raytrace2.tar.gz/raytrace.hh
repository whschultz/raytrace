//  file:  raytrace.hh

#ifndef RAYTRACE
#define RAYTRACE

#include "gpackage.hh"
#include "vector.hh"
#include "matrix.hh"
#include <qdatetime.h>
#include <qcursor.h>
#include <qcolor.h>
#include <qstring.h>

#define MAXOBJECTS 128
#define MAXLIGHTS  16
#define MAXSPECDEPTH 4


typedef enum {PLAIN,CHECKERED} pattern;

class lightsource
{
public:
  lightsource(void);
  ~lightsource(void);

  vector3 specular(vector3 dir,vector3 norm,vector3 intersect,double spec,double phong);
  vector3 diffuse(vector3 point,vector3 norm,vector3 direction,
		  double diffuse,double ambient,double phong,vector3 color);

  void setcolor(double,double,double); // 0.0 to 1.0
  void setcolor(int,int,int);          // 0 to 255
  void setposition(double,double,double);
  void setattenuation(double newatt) {attenuation=newatt;}

  vector3 getpos(void) {return position;}
private:
  vector3 position;
  vector3 color; // range from 0 to 1
  double  attenuation;
};


class raytraceobject
{
public:
  raytraceobject(void);
  virtual ~raytraceobject(void) { };
  virtual vector3 intersect(vector3,vector3,double *); // returns intersect point
  virtual vector3 intersectcolor(vector3,vector3,double *,lightsource); // returns color
  virtual vector3 reflect(vector3,vector3,double);
  virtual void setcenter(vector3);
  virtual void setcenter(double x,double y,double z) {center.setrectangular(x,y,z);}
  virtual void setradius(double);
  virtual void setcolor(int,int,int);
  virtual void setbackground(vector3 b) {background=b;}
  virtual void setbackground(int r,int g,int b) {background.setrectangular(r,g,b);}
  virtual void setambient(double a);
  virtual void setdiffuse(double d);
  virtual void setspecular(double s);
  virtual void setphong(double p) {phong=p;}
  virtual vector3 getnorm(vector3);
  virtual double getphong(void) {return phong;}
  virtual double getspecular(void) {return specular;}
  virtual double getdiffuse(void) {return diffuse;}
  virtual double getambient(void) {return ambient;}
  virtual vector3 getcolor(void) {return color;}

protected:
  vector3  center;
  double   radius;
  vector3  color;
  vector3  background;
  double   ambient;   // recode this to a vector3
  double   diffuse;   // recode this to a vector3
  double   specular;  // recode this to a vector3
  double   phong;
};


class sphere : public raytraceobject
{
public:
  sphere(void);
  ~sphere(void);
};


class plane : public raytraceobject
{
public:
  plane(void);
  ~plane(void);

  virtual vector3 intersect(vector3,vector3,double *);
  virtual vector3 intersectcolor(vector3,vector3,double *,lightsource);
  virtual vector3 reflect(vector3,vector3,double *);
  virtual void setpoint(double x,double y,double z) {point.setrectangular(x,y,z);}
  virtual void setnormal(double x,double y,double z) {normal.setrectangular(x,y,z);normal.makeunit();}
  virtual vector3 getnorm(vector3 irrelevant) {return normal;}
private:
  vector3 point;
  vector3 normal;
  pattern p;
};


class raytraceobjects
{
public:
  raytraceobjects(void);
  ~raytraceobjects(void);
  
  bool addobject(raytraceobject *);
  bool addlight(lightsource *);
  void setbackground(double,double,double);
  void deleteallobjects(void);
  void set_attenuation(double);

  vector3 followray(vector3,vector3,int);
  vector3 followraydiffuse(vector3,vector3,double,int);
  vector3 followrayspecular(vector3,vector3,double,int);

  vector3 intersect(vector3,vector3,double *);
  vector3 intersect(vector3,vector3,double *,int *);

  void remove_one_light(void);
  void remove_one_object(void);

private:
  vector3 background;
  raytraceobject **objects;
  lightsource    **lights;
  int numobjects,numlights;
  double attenuation;
};


class camera : public QWidget
{
  Q_OBJECT
public:
  camera(GP_Object *);
  ~camera(void) {}

  void tracescreen(void);
  vector3 tocamera(vector3);
  vector3 toworld(vector3);
  void setobjects(raytraceobjects *newobjs) {objects=newobjs;}
  void setaxes(void);
  
  void setlookat(double,double,double);
  void settop(double,double,double);
  void setpos(double,double,double);

  vector3 getvector(void);
  vector3 getcolor(void);

public slots:
  void drawscreen(void);
  void openfile(void);
  void setresolution(void);
  void set_camera_position_world(void);
  void set_camera_position_camera(void);
  void set_lookat_world(void);
  void set_lookat_camera(void);
  void set_top_world(void);
  void set_top_camera(void);
  void set_attenuation(void);
  void add_sphere(void);
  void add_plane(void);
  void add_light(void);
  void remove_last_light(void);
  void remove_last_object(void);
  void setbackground(void);

private:
  vector3  lookat;
  vector3  head;
  vector3  right;
  vector3  position;
  raytraceobjects *objects;
  GP_Object *gpobject;
  //matrix transform;
  int resolution;
};


#endif
