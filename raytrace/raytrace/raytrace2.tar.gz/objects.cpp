//  file:  objects.cpp

#include "raytrace.hh"
#include <iostream.h>
#include <qstring.h>
#include <qdatastream.h>


/*****************************************************/
//  functions for sphere

sphere::sphere(void)
{
  vector3 newcenter(0,0,0);
  setcenter(newcenter);
  setradius(20);
  setcolor(255,255,255);
}


sphere::~sphere(void)
{

  return;
}


/*****************************************************/
//  functions for lightsource

lightsource::lightsource(void)
{
  position.setrectangular(0,0,0);
  color.setrectangular(1,1,1);
  attenuation=3;
}


lightsource::~lightsource(void)
{

}


void lightsource::setposition(double x,double y,double z)
{
  position.setrectangular(x,y,z);
}


vector3 lightsource::diffuse(vector3 point,vector3 norm,vector3 direction,double diffuse,double ambient,double phong,vector3 colorobj)
{
  vector3 outputcolor;
  vector3 reflecteddir=direction;
  reflecteddir.reflect(norm);
  double adder1,adder2,dotp;
  if (norm.get_r() != 1)
    norm.makeunit();
  vector3 dirtolight=(position-point);
  double distance=dirtolight.norm();
  dirtolight.makeunit();
  adder1=diffuse*(norm*dirtolight);
  dotp=dot(reflecteddir,dirtolight);
  if (dotp>=0)
    adder2=pow(dotp,phong);
  else
    adder2=0;
  outputcolor.setrectangular(ambient*colorobj.x()+(255*attenuation*color.x()/distance)*(adder1+adder2),
			     ambient*colorobj.y()+(255*attenuation*color.y()/distance)*(adder1+adder2),
			     ambient*colorobj.z()+(255*attenuation*color.z()/distance)*(adder1+adder2));
  // the attenuation variable should be large for large coordinate values and small for small coordinate values
  return (outputcolor);
}


vector3 lightsource::specular(vector3 direction,vector3 norm,vector3 intersection,double specular,double phong)
{
  double distance;
  vector3 reflection_vector=direction;
  vector3 dirtolight=position-intersection;
  distance=dirtolight.norm();
  dirtolight.makeunit();
  reflection_vector.reflect(norm);
  return ((specular*pow(dot(reflection_vector,dirtolight),phong)*color)/distance);
}


void lightsource::setcolor(double r,double g,double b)
{
  color.setrectangular(r,g,b);
}


void lightsource::setcolor(int r,int g,int b)
{
  color.setrectangular(double(r)/255.0,
		       double(g)/255.0,
		       double(b)/255.0);
}


/*********************************************************/
//  function calls for plane

plane::plane(void)
{
  normal.setrectangular(0,0,1);
  point.setrectangular(0,0,0);
}


plane::~plane(void)
{

}


vector3 plane::intersect(vector3 start,vector3 direction,double *t)
{
  if (!dot(direction,normal))
    *t=-1;
  else
    *t=(dot(point,normal)-dot(start,normal))/dot(direction,normal);
  return (start+(*t)*direction);
}


vector3 plane::intersectcolor(vector3 start,vector3 direction,double *t,lightsource light)
{
  if (!dot(direction,normal))
    {
      *t=-1;
      return background;
    }
  vector3 outputcolor=color;
  vector3 intersection;
  vector3 lightfactor;

  intersection=intersect(start,direction,t);

  outputcolor=light.diffuse(intersection,normal,direction,diffuse,ambient,phong,color);
  /*outputcolor.setrectangular(lightfactor.x()*outputcolor.x(),
			     lightfactor.y()*outputcolor.y(),
			     lightfactor.z()*outputcolor.z());
			     outputcolor=ambient*color+outputcolor;*/
  
  outputcolor.cropforcolor();
  
  return outputcolor;
}


vector3 plane::reflect(vector3 start,vector3 direction,double *t)
{
  vector3 reflected_vector=direction;
  reflected_vector.reflect(normal);
  return reflected_vector;
}
