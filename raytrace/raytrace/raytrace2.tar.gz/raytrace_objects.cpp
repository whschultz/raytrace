//  file:  raytrace_objects.cpp

#include "raytrace.hh"
#include <iostream.h>
#include <qstring.h>
#include <qdatastream.h>


/*****************************************************/
//  functions for raytraceobjects

raytraceobjects::raytraceobjects()
{
  objects=new (raytraceobject *)[MAXOBJECTS];
  lights=new (lightsource *)[MAXLIGHTS];
  for(int x=0;x<MAXOBJECTS;x++)
    objects[x]=NULL;
  for(int x=0;x<MAXLIGHTS;x++)
    lights[x]=NULL;
  numobjects=0;
  numlights=0;
  attenuation=8;
  setbackground(150,100,255);
}


void raytraceobjects::setbackground(double r,double g,double b)
{
  background.setrectangular(r,g,b); 
  background.cropforcolor();
  for(int x=0;x<numobjects;x++)
    objects[x]->setbackground(background);
}


vector3 raytraceobjects::intersect(vector3 start,vector3 direction,
				   double *location,int *objectnumber)
{
  double t=1,smallest=-2;
  int numofsmallest=-1;
  *location=-1;
  *objectnumber=-1;
  for(int x=0;x<numobjects;x++)
    {
      objects[x]->intersect(start,direction,&t);
      if (t<=.00001)
	continue;
      else
	{
	  if (numofsmallest==-1)
	    {
	      smallest=t;
	      numofsmallest=x;
	      continue;
	    }
	  if (t<smallest)
	    {
	      smallest=t;
	      numofsmallest=x;
	    }
	}
    }
  if (numofsmallest != -1)
    {
      *location=smallest;
      *objectnumber=numofsmallest;
    }
  return (start+(smallest)*direction);
}


vector3 raytraceobjects::intersect(vector3 start,vector3 direction,double *location)
{
  int objectnumber;
  return intersect(start,direction,location,&objectnumber);
}


raytraceobjects::~raytraceobjects(void)
{
  deleteallobjects();
  delete [] objects;
  delete [] lights;
}


void raytraceobjects::deleteallobjects(void)
{
  while (numobjects--)
    delete objects[numobjects];
  while (numlights--)
    delete lights[numlights];
  numobjects=0;
  numlights=0;
}


void raytraceobjects::remove_one_object(void)
{
  if (numobjects==0)
    return;
  numobjects--;
  delete objects[numobjects];
}


void raytraceobjects::remove_one_light(void)
{
  if (numlights==0)
    return;
  numlights--;
  delete lights[numlights];
}


bool raytraceobjects::addobject(raytraceobject *newobject)
{
  if (numobjects >= MAXOBJECTS)
    return 0;
  newobject->setbackground(background);
  objects[numobjects]=newobject;
  numobjects++;
  return 1;
}


bool raytraceobjects::addlight(lightsource *newlight)
{
  if (numlights >= MAXLIGHTS)
    return 0;
  
  newlight->setattenuation(attenuation);
  lights[numlights]=newlight;
  numlights++;
  return 1;
}


void raytraceobjects::set_attenuation(double newatt)
{
  for(int x=0;x<numlights;x++)
      lights[x]->setattenuation(newatt);
  attenuation=newatt;
}


vector3 raytraceobjects::followrayspecular(vector3 start,vector3 dir,double t,int objectnumber)
{
  vector3 intersection;
  vector3 outputcolor(0,0,0);
  vector3 norm;
  vector3 spare;

  if (t>0)
    {
      norm=objects[objectnumber]->getnorm(intersection);
      for(int x=0;x<numlights;x++)
	outputcolor=outputcolor+
	  (lights[x]->specular(dir,norm,intersection,objects[objectnumber]->getspecular(),
			       objects[objectnumber]->getphong()));
      outputcolor.cropforcolor();
    }
  return outputcolor;
}


vector3 raytraceobjects::followraydiffuse(vector3 start,vector3 direction,double t,int numofsmallest)
{
  vector3 outputcolorv(0,0,0);
  vector3 spare;
  vector3 intersectionpoint,newdirection;
  vector3 deletethislater;
  double shadowpoint,distance;
  if (numofsmallest != -1)
    {
      intersectionpoint=(start+(t*direction));
      for(int y=0;y<numlights;y++)
	{
	  newdirection=(lights[y]->getpos()-intersectionpoint);
	  distance=((lights[y]->getpos())-(start+(t*direction))).norm();
	  newdirection.makeunit();
	  intersect(intersectionpoint,newdirection,&shadowpoint);
	  if ((shadowpoint < 0) || (shadowpoint > distance))
	    {
	      outputcolorv=(outputcolorv+
			    (objects[numofsmallest]->intersectcolor(start,direction,&t,
								    *(lights[y]))));
	    }
	}
      outputcolorv.cropforcolor();
    }
  else
    outputcolorv=background;
  
  return outputcolorv;
}


vector3 raytraceobjects::followray(vector3 start,vector3 direction,int currentdepth)
{
  double smallest=-2;
  int numofsmallest=-1;
  vector3 outputcolorv(0,0,0);
  vector3 spare;
  vector3 intersectionpoint,newdirection=direction;

  intersectionpoint=intersect(start,direction,&smallest,&numofsmallest);
  if (numofsmallest != -1)
    {
      outputcolorv=followraydiffuse(start,direction,smallest,numofsmallest);
      //	+followrayspecular(start,direction,smallest,numofsmallest);
      if ((currentdepth < MAXSPECDEPTH) && (objects[numofsmallest]->getspecular() > 0))
	{
	  newdirection.reflect(objects[numofsmallest]->getnorm(intersectionpoint));
	  outputcolorv=outputcolorv+((objects[numofsmallest]->getspecular())
				     *(followray(intersectionpoint,newdirection,currentdepth+1)));
	}
    }
  else
    outputcolorv=background;
  
  outputcolorv.cropforcolor();
  
  return outputcolorv;
}
