//
// Qt OpenGL example: Box
//
// A small example showing how a GLWidget can be used just as any Qt widget
// 
// File: main.cpp
//
// The main() function 
// 

#include "raytrace.hh"
#include "mainwin.hh"
#include <qapplication.h>
//#include "matrix.hh"

/*
  The main program is here. 
*/

int main( int argc, char **argv )
{
  QApplication::setColorSpec( QApplication::CustomColor );
  QApplication a(argc,argv);			
  
  MainWindow w;
  //w.resize( 800, 600 );
  a.setMainWidget( &w );
  w.show();
  
  w.getName();
  
  return a.exec();
}
