/*
 *  vector.h
 *  Modeler
 *
 *  Created by William H. Schultz  on Wed Mar 13 2002.
 *  Copyright (c) 2001 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef NEWVECTORWHS
#define NEWVECTORWHS

#include <math.h>

#define vector3 vector  // this is done to trick out the compiler
#define pi 3.1415926535897946264338
//const double pi = 2*acos(0);


class vector
{
public:
  
  vector(void);
  vector(double,double,double);
  vector(const vector &);
  
  void set_equal_to(const vector &);
  int  check_equal(const vector &);
  
  void set_x(double);  // these methods are not recommended.
  void set_y(double);  // the system will not automatically
  void set_z(double);  // convert the vector format.
  void setrectangular(double,double,double);  // preferred
  void set_r(double);  // these methods are not recommended
  void set_theta(double);
  void set_phi(double);
  void set_spherical(double,double,double);  // preferred
  
  void makeunit(void);
  
  double get_x(void);
  double get_y(void);
  double get_z(void);
  double get_r(void);
  double get_theta(void);
  double get_phi(void);
  
  // legacy support
  double x(void) {return get_x();}
  double y(void) {return get_y();}
  double z(void) {return get_z();}

  // vector arithmetic
  double dot(vector);
  vector cross(vector);
  vector add(vector);
  vector subtract(vector);
  double norm(void);
  void make_unit(void);
  void reflect(vector);

  // scalar arithmetic
  vector multiply(double);
  vector divide(double);


  // legacy support
  friend vector operator*(double a, vector3 v);
  friend double operator*(vector3 a, vector3 b) {return a.dot(b);}
  friend vector operator+(vector a,vector b);
  friend vector operator/(vector a,double b);
  friend vector operator-(vector a,vector b) {return (a+(-1*b));}
  void cropforcolor(void);

  
protected:
  
  void update_rectangular(void);
  void update_spherical(void);
  
private:
  double x_coor;
  double y_coor;
  double z_coor;
  double r,theta,phi;
  short mode;  //  1 for rectangular, 2 for spherical, 3 for both
};


vector cross(vector,vector);
double dot(vector a,vector b) {return a.dot(b);}

#endif
