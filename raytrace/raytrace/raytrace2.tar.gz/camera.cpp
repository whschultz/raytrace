//  file:  camera.cpp

#include "raytrace.hh"
#include <iostream.h>
#include <fstream.h>
#include <qstring.h>
#include <qdatastream.h>
#include <qdatetime.h>
#include <qprogressdialog.h>
#include <qprogressbar.h>
#include <qfile.h>
#include <qfiledialog.h>


/*****************************************************/
//  functions for camera

camera::camera(GP_Object *newgp)
{
  lookat.setrectangular(0,-1,-1);
  lookat.makeunit();
  head.setrectangular(0,1,0);
  position.setrectangular(0,10,10);
  gpobject=newgp;
  resolution=1;
  setaxes();
}


void camera::drawscreen(void)
{
  tracescreen();
}


void camera::setlookat(double x, double y, double z)
{
  lookat.setrectangular(x,y,z);
  lookat.makeunit();
  setaxes();
}


void camera::settop(double x, double y, double z)
{
  head.setrectangular(x,y,z);
  setaxes();
}


void camera::setpos(double x,double y,double z)
{
  position.setrectangular(x,y,z);
}


vector3 camera::getvector(void)
{
  vector3 output(0,0,0);
  double x,y,z;
  cout << "\nPlease input three values (x y z):  ";
  cin >> x >> y >> z;
  cout << endl;

  output.setrectangular(x,y,z);

  return output;
}


vector3 camera::getcolor(void)
{
  vector3 output(0,0,0);
  double x,y,z;
  cout << "\nPlease input three integers [0,255] (r g b):  ";
  cin >> x >> y >> z;
  cout << endl;

  output.setrectangular(x,y,z);
  output.cropforcolor();

  return output;
}


void camera::setaxes(void)
{
  right=lookat.cross(head);
  head=right.cross(lookat);  // make head normal to lookat
  right.makeunit();
  head.makeunit();
  lookat.makeunit();
}


void camera::tracescreen(void)
{
  while (!gpobject->GP_IsEmpty())
    gpobject->GP_DeletePoly(0);
  QProgressDialog dialog("tracing rays...","Cancel",720);
  QString labeltext;

  QTime    timer;
  vector3  direction;
  vector3  topleft,topright,bottomleft,bottomright,spare,currentxy;
  vector3  Xdir,Ydir;
  int X=0,Y=0;
  QColor  current;
  vector3 currentv;

  topright=(lookat+right+(486*head)/720);
  topleft=(lookat-right+(486*head)/720);
  bottomleft=(lookat-right-(486*head)/720);
  bottomright=(lookat+right-(486*head)/720);

  Xdir=topright-topleft;
  Xdir= Xdir/720;
  Ydir=(topleft-bottomleft)/486;

  spare=bottomleft;

  timer.start();

  for(X=0;X<=720;X+=resolution)
    {
      currentxy=spare;
      for(Y=0;Y<=486;Y+=resolution)
	{
	  direction=(lookat+currentxy);
	  direction.makeunit();
	  currentv=objects->followray(position,direction,0);
	  current.setRgb(currentv.x(),
			 currentv.y(),
			 currentv.z());
	  if (resolution<=1)
	    gpobject->GP_DrawPixel(X,Y,current);
	  else
	    {
	      for(int a=X;a<X+resolution;a++)
		for(int b=Y;b<Y+resolution;b++)
		  gpobject->GP_DrawPixel(a,b,current);
	    }
	  currentxy=currentxy+resolution*Ydir;
	}
      spare=spare+resolution*Xdir;
      dialog.setProgress(X);
      if (int(double(X)/double(resolution))%5 == 0)
	gpobject->GP_RefreshScreen();
      double current=(double(timer.elapsed())/double(1000));
      double total=current*(double(720)/(double(X+1)));
      double remaining=total-current;
      labeltext="";
      labeltext.sprintf("\nEstimated total time:     %i seconds\nEstimated remaining time: %i\nElapsed:  %i",
			int(total),int(remaining),int(current));
      dialog.setLabelText(labeltext);
      if (dialog.wasCancelled())
	return;
    }
  cout << "Total elapsed time:  " << timer.elapsed()/1000 << " seconds" << endl; 
}


vector3 camera::tocamera(vector3 input)
{
  matrix transform(3,3),intermediate(3,1);
  vector3 output,spare;

  transform.set(0,0,right.x());
  transform.set(0,1,head.x());
  transform.set(0,2,lookat.x());

  transform.set(1,0,right.y());
  transform.set(1,1,head.y());
  transform.set(1,2,lookat.y());

  transform.set(2,0,right.y());
  transform.set(2,1,head.y());
  transform.set(2,2,lookat.y());

  transform.inverse();
  spare=input-position;

  intermediate=transform*spare;

  output.setrectangular(intermediate.get(0,0),
			intermediate.get(1,0),
			intermediate.get(2,0));
  return output;
}


vector3 camera::toworld(vector3 input)
{
  vector3 output;
  output=(position+(input.x()*right)+(input.y()*head)+(input.z()*lookat));
  return output;
}


void camera::openfile(void)
{
  lightsource    *light;
  raytraceobject *object;
  QFile           inputfile;
  QFileDialog     dialog;
  float           **surfaces;

  inputfile.setName(dialog.getOpenFileName("./","*.dat",gpobject,
					   "Open Data File..."));
  ifstream file(inputfile.name(),ios::in);
  
  float x,y,z,ambient,radius;
  int   num,numsurfaces,surfaceID;
  char  c;
  
  objects->deleteallobjects();

  if (file >> x >> y >> z)
    {
      cout << "Ambient:    " << x << " " << y << " " << z << endl;
      ambient=(x+y+z)/3;
    }
  else
    {
      cout << "ERROR IN FILE at 1!!!!!!!" << endl;
      return;
    }
  if (file >> num)
    {
      cout << "Point:      " << num << endl;
      while (num--)
	{
	  file >> x >> y >> z;
	  cout << "           " << x << " " << y << " " << z << endl;
	  light = new lightsource;
	  light->setposition(x,y,z);
	  light->setcolor(1.0,1.0,1.0);
	  objects->addlight(light);
	}
    }
  else
    {
      cout << "ERROR IN FILE at 2!!!!!!!!!!" << endl;
      return;
    }
  if (file >> numsurfaces)
    {
      cout << "Surfaces:      " << numsurfaces << endl;
      surfaces = new (float *)[numsurfaces];
      for(int q=0;q<numsurfaces;q++)
	{
	  surfaces[q]= new float[10];
	  for(int m=0;m<10;m++)
	    {
	      file >> surfaces[q][m];
	      cout << surfaces[q][m] << " ";
	      if ((m%3)==2)
		cout << endl;
	    }
	  cout << endl;
	}
      cout << endl;
    }
  else
    {
      cout << "ERROR IN FILE at 3!!!!!!!!!!" << endl;
      return;
    }
  if (file >> num)
    {
      cout << "Objects       " << num << endl;
      for(int q=0;q<num;q++)
	{
	  file >> c >> x >> y >> z >> radius >> surfaceID;
	  cout << "        " << c << " " << x << " " << y << " " << z << " " 
	       << radius << " " <<surfaceID << endl;
	  switch (c)
	    {
	    case ('S'):
	    default:
	      object = new sphere;
	      object->setcenter(x,y,z);
	      object->setradius(radius);
	      break;
	    }
	  double r,g,b;
	  r=surfaces[surfaceID-1][3];
	  g=surfaces[surfaceID-1][4];
	  b=surfaces[surfaceID-1][5];
	  object->setcolor(int(255*r),int(255*g),int(255*b));
	  object->setambient(surfaces[surfaceID-1][0]);
	  object->setdiffuse((r+g+b)/3);
	  object->setspecular(surfaces[surfaceID-1][6]);
	  object->setphong(surfaces[surfaceID-1][9]);
	  
	  object->setcolor(255,255,255);

	  objects->addobject(object);
	  
	}
    }
  else
    {
      cout << "ERROR IN FILE at 4!!!!!!!!!!" << endl;
      return;
    }

  for(int q=0;q<numsurfaces;q++)
    delete surfaces[q];
  delete [] surfaces;
  cout << "Success opening file" << endl;
}


void camera::setresolution(void)
{
  cout << "\nPlease input a new drawing resolution.  (a value of 3 means rays are 3 pixels wide):  ";
  cin >> resolution;
  if (resolution < 1)
    resolution=1;
}


void camera::set_camera_position_world(void)
{
  position=getvector();
}


void camera::set_camera_position_camera(void)
{
  vector3 newposition=getvector();
  position=(position+(newposition.x()*right)+(newposition.y()*head)
	    +(newposition.z()*lookat));
}


void camera::set_lookat_world(void)
{
  lookat=getvector();
  setaxes();
}


void camera::set_lookat_camera(void)
{
  vector3 newlookat=getvector();
  lookat=((newlookat.x()*right)+(newlookat.y()*head)+
	  (newlookat.z()*lookat));
  setaxes();
}


void camera::set_top_world(void)
{
  head=getvector();
  setaxes();
}


void camera::set_top_camera(void)
{
  vector3 newtop=getvector();
  head=((newtop.x()*right)+(newtop.y()*head)+
       (newtop.z()*lookat));
  setaxes();
}


void camera::set_attenuation(void)
{
  double newatt;
  cout << "Please input a new light attenuation factor:  ";
  cin >> newatt;
  objects->set_attenuation(newatt);
}



void camera::add_sphere(void)
{
  sphere *newsphere=new sphere;
  double radius;
  double amb,diff,spec,phong;
  cout << "Please input a center point:\n";
  vector3 center=getvector();
  cout << "Please input a radius:  ";
  cin >> radius;
  cout << "\nPlease input a color:\n";
  vector3 color=getcolor();
  cout << "Please input ambient reflection coeficient:  ";
  cin >> amb;
  cout << "\nPlease input diffuse reflection coeficient:  ";
  cin >> diff;
  cout << "\nPlease input specular reflection coeficient:  ";
  cin >> spec;
  cout << "\nPlease input phong value:  ";
  cin >> phong;
  cout << "\n";
  newsphere->setcenter(center);
  newsphere->setradius(radius);
  newsphere->setcolor(color.x(),color.y(),color.z());
  newsphere->setambient(amb);
  newsphere->setdiffuse(diff);
  newsphere->setspecular(spec);
  newsphere->setphong(phong);

  objects->addobject(newsphere);

}


void camera::add_plane(void)
{
  plane *newplane=new plane;
  double amb,diff,spec,phong;
  cout << "Please input a reference point:\n";
  vector3 point=getvector();
  cout << "Please input the normal vector:  ";
  vector3 norm=getvector();
  cout << "\nPlease input a color:\n";
  vector3 color=getcolor();
  cout << "Please input ambient reflection coeficient:  ";
  cin >> amb;
  cout << "\nPlease input diffuse reflection coeficient:  ";
  cin >> diff;
  cout << "\nPlease input specular reflection coeficient:  ";
  cin >> spec;
  cout << "\nPlease input phong value:  ";
  cin >> phong;
  cout << "\n";
  newplane->setpoint(point.x(),point.y(),point.z());
  newplane->setnormal(norm.x(),norm.y(),norm.z());
  newplane->setcolor(color.x(),color.y(),color.z());
  newplane->setambient(amb);
  newplane->setdiffuse(diff);
  newplane->setspecular(spec);
  newplane->setphong(phong);

  objects->addobject(newplane);

}


void camera::add_light(void)
{
  lightsource *light=new lightsource;
  cout << "Please input the position:  ";
  vector3 pos=getvector();
  cout << "\nPlease input a color:\n";
  vector3 color=getcolor();
  light->setcolor(int(color.x()),int(color.y()),int(color.z()));
  light->setposition(pos.x(),pos.y(),pos.z());
  objects->addlight(light);
}


void camera::remove_last_light(void)
{
  objects->remove_one_light();
}


void camera::remove_last_object(void)
{
  objects->remove_one_object();
}


void camera::setbackground(void)
{
  cout << "Please input a new background color:\n";
  vector3 color=getcolor();
  objects->setbackground(color.x(),color.y(),color.z());
}
